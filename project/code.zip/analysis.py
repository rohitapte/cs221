"""
analyze the effect of mu on recurrent reinforcement learning algo profitability
"""
#!/usr/bin/env python3

import pnl
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from reinforcement import Reinforcement
from datetime import datetime

def getDefaultFileName():

    return "%s_%s%s%s" %(str(datetime.now().date()), datetime.now().hour, datetime.now().minute, datetime.now().second)

## variables
M = 10
N = 100
mu = 10
delta = 1.5
riskAdj = True
rewardFunc = "Sortino"
optimizer = "gradient_ascent"
numTrainDays = 30
numTestDays = 10
dataFileName = "ohlc_60"
dataPath = "/home/tesa/cs221/project/dataFrames/HKFE/HSI/"
resultsFileName = getDefaultFileName()
# resultsFilePath = "/home/tesa/cs221/project/results/"
resultsFilePath = None
pointValue = 50
showPlots = False

optDict = {
  "thresh": 10.0,
  "batchSize": 32,
  "alpha": 0.001,
  "precision": 0.00001,
  "verbose": True
}



def runRRL(*args, **optDict):
    ## instantiate Reinforcement for each test size
    reinforce = Reinforcement(M=M, N=N, mu=mu, delta=delta, riskAdj=riskAdj,
                              rewardFunc=rewardFunc, optimizer=optimizer)
    ## initialize training, test days
    print("initializing...")
    reinforce.initialize(numTrainDays, numTestDays, fileName=dataFileName, dataPath=dataPath)

    ## run backtest
    print("running backtest...")
    results = reinforce.rollCycle(**optDict)

    ## evaluate
    filePath = "%s/%s" %(resultsFilePath, resultsFileName)
    reinforce.evaluateResults(results, showPlots=showPlots, filePath=filePath, pointValue=pointValue)

    return reinforce

def plotMultiResults(resultsDict, title=None, savePlot=None, closePlot=False):

    keys = list(resultsDict.keys())
    tdf = resultsDict[keys[0]].pnlSummary

    # get plt times
    xs, hfmt = pnl.formatStringTime(tdf.index.format(), formatType="%Y%m%d")

    fig = plt.figure()
    ax = fig.add_subplot(1, 1, 1)
    ##
    for key in keys:
        df = resultsDict[key].pnlSummary
        csNetPnl = df.netPnl.cumsum()/df.netPnl.mean()
        xs, thfmt = pnl.formatStringTime(df.index.format(), formatType="%Y%m%d")
        ax.plot(xs, csNetPnl.values, "-", label="%s" %(key))
    ax.xaxis.set_major_formatter(hfmt)
    plt.gcf().autofmt_xdate(rotation=45)
    ax.set_ylabel("Normalized netPnl")
    plt.legend(loc="upper left")

    if title != None:
        fig.suptitle("%s - %s %s" %(tdf.index[0], tdf.index[-1], title))
    else:
        fig.suptitle("%s - %s" % (tdf.index[0], tdf.index[-1]))

    if savePlot != None:
        fig.savefig(savePlot)

    plt.show()

    if closePlot:
        plt.close(fig)

    return fig

mList = [20, 30, 40, 50, 60]

resultsDict = {}
for numTrainDays in mList:
    print(numTrainDays)
    resultsDict[numTrainDays] = runRRL(numTrainDays, **optDict)

fig = plotMultiResults(resultsDict, title="numTrainDays", savePlot=None, closePlot=False)