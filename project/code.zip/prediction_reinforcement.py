"""
reinforcement learning class
"""
#!/usr/bin/env python3

import os
import data
import pnl
import numpy as np
import optimizers as opt
import prediction_utils as putils
import pandas as pd
import matplotlib.pyplot as plt

optDict = {
  "thresh": 10.0,
  "batchSize": 32,
  "alpha": 0.001,
  "precision": 0.00001,
  "verbose": True
}

class PredictionReinforcement(object):
    def __init__(self, N=100, mu=1, delta=1.5, riskAdj=False, rewardFunc="Sortino", optimizer="gradient_ascent"):
        self.N = N      # number iterations
        self.mu = mu    # number shares traded
        self.delta = delta      # transaction costs should be 2 bps (1.00 = 1% return)
        self.riskAdj = riskAdj  # True: tradeQty = mu, False: tradeQty = probability * mu
        self.rewardFunc = rewardFunc
        self.optimizer = optimizer   # gradient_ascent, sga

    def initialize(self, trainDays, testDays, startDate=None, predClasses=["-1.0", "0.0", "1.0"], predFileName="predictions",\
                   predPath="/home/tesa/cs221/project/predictions/", priceFileName="ohlc_60", \
                   pricePath="/home/tesa/cs221/project/dataFrames/HKFE/HSI/"):
        """
        :param predClasses: list of prediction classes ie ["-1.0", "0.0", "1.0"], ["target"]
        """
        # set training_dates, test_dates
        self.numTrainDays = trainDays
        self.numTestDays = testDays
        print("Getting predictions from %s%s" %(predPath, predFileName))
        self.train_px, self.test_px, self.train_preds, self.test_preds, self.train_dates, self.test_dates = \
            data.getTrainTestPreds(startDate=startDate, trainDays=trainDays, testDays=testDays, predFileName=predFileName, \
                        predPath=predPath, priceFileName=priceFileName, pricePath=pricePath)

        # set theta
        print("Initializing theta...")
        self.theta = np.ones(3)
        self.predClasses = [str(x) for x in predClasses]


    def rollCycle(self, **optParams):

        self.results = {}

        for i in self.train_preds.keys():
            print(i)
            # get train_X, test_X
            train_X = self.train_preds[i][self.predClasses].values
            train_returns = self.train_px[i]["lnRet"].values
            test_X = self.test_preds[i][self.predClasses].values
            test_returns = self.test_px[i]["lnRet"].values
            self.results[i] = self.runCycle(train_X, test_X, train_returns, test_returns, **optParams)

        return self.results

    def runCycle(self, train_X, test_X, train_returns, test_returns, **optParams):

        # if i > 0:
        # optimize costFunc for train_X
        if self.optimizer == "gradient_ascent":
            self.theta = opt.gradient_ascent_probs(train_X, train_returns, self.theta, self.predClasses, mu=self.mu, \
                                                   delta=self.delta, riskAdj=self.riskAdj, maxSteps=self.N, **optParams)
        else:
            self.theta = opt.stochastic_gradient_ascent_probs(train_X, train_returns, self.theta, self.predClasses, \
                                            mu=self.mu, delta=self.delta, maxSteps=self.N, **optParams)

        # update Ft for test_X
        Ft = putils.updateFt(test_X, self.theta, self.predClasses, riskAdj=self.riskAdj)

        # get return, score for test_X
        tradeRet, score = putils.rewardFunction(test_returns, self.mu, self.delta, Ft, \
                                               rewardFunc=self.rewardFunc)

        # get cumulative return for test_X
        # cumRet = utils.getCumulativeReturn(tradeRet)
        cumRet = np.cumsum(tradeRet/100.0)[-1]

        # get number of trade info
        numTrades = sum(abs(np.diff(Ft)))
        tradeCosts = putils.getTradeCosts(self.mu, Ft, self.delta)
        position = putils.getPosition(self.mu, Ft)

        # save info
        results = {"tradeSignals":Ft,
                   "tradeReturns":tradeRet,
                   "theta":self.theta,
                   "cumRet":cumRet,
                   "scoreType":self.rewardFunc,
                   "score":score,
                   "numTrades":numTrades,
                   "tradeCosts":tradeCosts,
                   "position":position}

        # for key, item in results.items():
        #     print(key, item)

        return results

    def convertResults(self, results):

        ## set variables
        self.tradeSignals = np.array([])
        self.tradeReturns = np.array([])
        self.position = np.array([])
        self.tradeCosts = np.array([])
        self.testDates = np.array([])

        for key, item in results.items():
            self.tradeSignals = np.append(self.tradeSignals, item["tradeSignals"])
            self.tradeReturns = np.append(self.tradeReturns, item["tradeReturns"])
            self.position = np.append(self.position, item["position"])
            self.tradeCosts = np.append(self.tradeCosts, item["tradeCosts"])
            self.testDates = np.append(self.testDates, self.test_dates[key])

        ## get calcs
        self.tradeQty = np.array([0.0])
        self.tradeQty = np.append(self.tradeQty, np.diff(self.position))
        self.sumTradeQty = sum(abs(self.tradeQty))
        self.sumNumTrades = sum(abs(self.tradeSignals))
        self.sumTradeCostsBps = sum(self.tradeCosts)/10000.0 #convert back to 0.0001 price space bps
        self.totalTestDays = len(self.testDates)

        if self.rewardFunc == "Sortino":
            self.score = putils.sortinoRatio(self.tradeReturns)
        else:
            self.score = putils.sharpeRatio(self.tradeReturns)

    def getIntradayResults(self, filePath=None, pointValue=50):
        pnlDf = pnl.getPnlDf(self, pointValue)
        pnlSummary, pnlDict = pnl.getDailyPnl(pnlDf, self, pointValue=pointValue)

        if filePath != None:
            pnlSummary.to_csv("%s/intraday_pnl_summary.csv" %(filePath))

        if self.rewardFunc == "Sortino":
            self.intradayScore = putils.sortinoRatio(pnlSummary.pnl.values)
        else:
            self.intradayScore = putils.sharpeRatio(pnlSummary.pnl.values)

        return pnlSummary

    def evaluateResults(self, results, showPlots=False, filePath=None, pointValue=50):
        """
        :param results: 
        :param filePath: root filePath for files
        :param pointValue: 
        :return: 
        """

        self.convertResults(results)
        keys = list(self.test_dates.keys())
        # check for filePath directory
        if filePath != None:
            if not os.path.exists(filePath):
                os.makedirs(filePath)
        self.pnlSummary = self.getIntradayResults(filePath=filePath, pointValue=pointValue)


        print("PARAMETERS")
        print("Total test days: %s" %(self.totalTestDays))
        print("startDate: %s endDate: %s" %(self.test_dates[0][0], self.test_dates[keys[-1]][-1]))
        print("maxTradedQty: %s riskAdj: %s" %(self.mu, self.riskAdj))
        print("------------------------------------------\n")
        print("CUMULATIVE PNL")
        print("------------------------------------------")
        print("%s: %s" %(self.rewardFunc, round(self.score,2)))
        print("sumReturn: %s" %(round(np.sum(self.tradeReturns/10000.0),2)))
        print("cumReturn: %s" %(round(np.cumsum(self.tradeReturns/10000.0)[-1], 2)))
        print("tot tradeCostsBps: %s" % (self.sumTradeCostsBps))
        print("------------------------------------------")
        print("avg daily return: %s" %(round(np.sum(self.tradeReturns/10000.0)/self.totalTestDays, 2)))
        print("avg trades per day: %s" %(round(self.sumNumTrades*1.0/self.totalTestDays, 2)))
        print("avg contracts per day: %s" %(round(self.sumTradeQty*1.0/self.totalTestDays, 2)))
        print("avg tradeCosts per day: %s" %(round(self.sumTradeCostsBps/self.totalTestDays, 2)))
        print("avg position per day: %s" %(round(self.position.sum()/self.totalTestDays, 2)))
        print("------------------------------------------")
        print("min return: %s" %(round(self.tradeReturns.min()/10000.0, 4)))
        print("max return: %s" % (round(self.tradeReturns.max() / 10000.0, 4)))
        print("median return: %s" % (round(np.median(self.tradeReturns) / 10000.0, 4)))

        ## intraday pnl
        print("\nINTRADAY PNL")
        print("------------------------------------------")
        print("sharpe: %s" % (round(putils.sharpeRatio(self.pnlSummary.pnl.values), 2)))
        print("sortino: %s" % (round(putils.sortinoRatio(self.pnlSummary.pnl.values), 2)))
        print("sumPnl: %s" %self.pnlSummary.pnl.sum())
        print("sumFees: %s" %self.pnlSummary.fees.sum())
        print("netPnl: %s" %(self.pnlSummary.netPnl.sum()))
        print("------------------------------------------")
        print("avg pnl: %s" %(round(self.pnlSummary.pnl.mean(), 0)))
        print("maxDrawDown: %s" % (round(self.pnlSummary.pnl.min(), 0)))
        print("avg tradeCosts: %s" %(round(self.pnlSummary.fees.mean(), 0)))
        print("avg netPnl: %s" %(round(self.pnlSummary.netPnl.mean(), 0)))
        print("avg numTrades: %s" %(round(self.pnlSummary.numTrades.mean(), 0)))
        print("avg numContracts: %s" %(round(self.pnlSummary.numCts.mean(), 0)))
        print("avg contracts per Trade: %s" %(round(self.pnlSummary.numCts.mean()/self.pnlSummary.numTrades.mean(), 2)))

        ## write to file
        if filePath != None:
            self.writeToFile(filePath + "/pnl_summary.txt")
            ##
            plot_title = "mu: %s numTrain: %s numTest: %s riskAdj: %s" \
                         % (self.mu, self.numTrainDays, self.numTestDays, self.riskAdj)
            ## histogram
            hist_fig = pnl.plotPnlHistogram(self.pnlSummary.pnl, bins=20, title=plot_title,
                                            savePlot=filePath + "/daily_pnl_histogram.png", closePlot=False)
            ## daily cumulative pnl
            cumPnl_fig = pnl.plotCumPnl(self.pnlSummary.pnl, title=plot_title, \
                                        savePlot=filePath + "/daily_cum_pnl.png", closePlot=False)
            ## intraday cumulative pnl
            intraCumPnl_fig = pnl.plotCumPnlAndDailyBarChart(self.pnlSummary.pnl, title=plot_title,
                                                             savePlot=filePath + "/intraday_cum_pnl_bar_chart.png",
                                                             closePlot=False)
        ## plots
        if not showPlots:
            plt.close(hist_fig)
            plt.close(cumPnl_fig)
            plt.close(intraCumPnl_fig)

    def writeToFile(self, filePath):

        if filePath != None:
            file = open(filePath, "w")
            ## params
            file.write("PARAMETERS\n")
            file.write("N: %s\n" %self.N)
            file.write("mu: %s\n" %self.mu)
            file.write("delta: %s\n" %self.delta)
            file.write("riskAdj: %s\n" %self.riskAdj)
            file.write("rewardFunction: %s\n" %(self.rewardFunc))
            file.write("optimizer: %s\n" %self.optimizer)
            file.write("numTrainDays: %s\n" %self.numTrainDays)
            file.write("numTestDays: %s\n" %self.numTestDays)
            file.write("Total test days: %s\n" % (self.totalTestDays))
            file.write("startDate: %s endDate: %s\n" % (self.test_dates[0][0], \
                                                      self.test_dates[list(self.test_dates.keys())[-1]][-1]))
            file.write("------------------------------------------\n")
            ## straight pnl
            file.write("\nCUMULATIVE PNL\n")
            file.write("%s: %s\n" % (self.rewardFunc, round(self.score, 2)))
            file.write("sumReturn: %s\n" % (round(np.sum(self.tradeReturns / 10000.0), 2)))
            file.write("cumReturn: %s\n" % (round(np.cumsum(self.tradeReturns/10000.0)[-1], 2)))
            file.write("tot tradeCostsBps: %s\n" % (self.sumTradeCostsBps))
            file.write("------------------------------------------\n")
            file.write("avg daily return: %s\n" % (round(np.sum(self.tradeReturns / 10000.0) / self.totalTestDays, 2)))
            file.write("avg trades per day: %s\n" % (round(self.sumNumTrades * 1.0 / self.totalTestDays, 2)))
            file.write("avg contracts per day: %s\n" % (round(self.sumTradeQty * 1.0 / self.totalTestDays, 2)))
            file.write("avg tradeCosts per day: %s\n" % (round(self.sumTradeCostsBps / self.totalTestDays, 2)))
            file.write("avg position per day: %s" % (round(self.position.sum() / self.totalTestDays, 2)))
            file.write("------------------------------------------\n")
            ## daily pnl
            file.write("\nINTRADAY PNL\n")
            file.write("------------------------------------------\n")
            file.write("sharpe: %s" % (round(putils.sharpeRatio(self.pnlSummary.pnl.values), 2)))
            file.write("sortino: %s" % (round(putils.sortinoRatio(self.pnlSummary.pnl.values), 2)))
            file.write("sumPnl: %s\n" %self.pnlSummary.pnl.sum())
            file.write("sumFees: %s\n" %self.pnlSummary.fees.sum())
            file.write("netPnl: %s\n" %(self.pnlSummary.netPnl.sum()))
            file.write("------------------------------------------\n")
            file.write("avg pnl: %s\n" %(round(self.pnlSummary.pnl.mean(), 0)))
            file.write("maxDrawDown: %s\n" %(round(self.pnlSummary.pnl.min(), 0)))
            file.write("avg tradeCosts: %s\n" %(round(self.pnlSummary.fees.mean(), 0)))
            file.write("avg netPnl: %s\n" %(round(self.pnlSummary.netPnl.mean(), 0)))
            file.write("avg numTrades: %s\n" %(round(self.pnlSummary.numTrades.mean(), 0)))
            file.write("avg numContracts: %s\n" %(round(self.pnlSummary.numCts.mean(), 0)))
            file.write("avg contracts per Trade: %s\n" %(round(self.pnlSummary.numCts.mean() / self.pnlSummary.numTrades.mean(), 2)))

            file.close()