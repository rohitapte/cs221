"""
file of optimizers gradient descent

The following variables should be passed in optDict to reinforcement.runCycle(**optDict)
OPTDICT VARIABLES:
   thresh = threshold for y definition, not used
   batchSize = number of returns to batch for stochastic_gradient_ascent
   alpha = step size in gradient evaluation (aka eta)
   maxSteps = max number of iterations in gradient calculation
   precision = threshold to determine stopping point for gradient_ascent
   verbose = flag to print each update

"""
#!/usr/bin/env python3

import utils
import prediction_utils as putils
import numpy as np


def gradient_ascent(X, theta_init, mu = 1, delta = 2, riskAdj=False, maxSteps=100,\
                    thresh=0.0, batchSize=0.0, alpha=0.001, precision=0.00001, verbose=False):
    # variables
    theta = theta_init
    counter = 0
    old_cost = 0
    thetas = []
    costs = []

    # get current costs
    current_cost = utils.costFunction(X, theta, mu, delta, riskAdj=riskAdj)  ## replace cost function here

    # update arrays
    thetas.append(theta)
    costs.append(current_cost)
    counter += 1

    while abs(current_cost - old_cost) > precision:
        # calc new theta
        old_cost = current_cost
        ## gradient calc
        gradient = utils.gradientUt(X, theta, mu, delta, riskAdj=riskAdj)
        ## update theta
        theta = theta + alpha * gradient
        thetas.append(theta)

        ## get cost
        current_cost = utils.costFunction(X, theta, mu, delta, riskAdj=riskAdj)
        costs.append(current_cost)
        counter += 1

        # prints
        if verbose:
            if counter % 10 == 0:
                print("Iteration: %s cost: %s" %(counter, current_cost))

        # break
        if counter >= maxSteps:
            break

    # optimal theta
    opt_index = np.argmax(costs)
    # print("index: %s opt_cost: %s" %(opt_index, costs[opt_index]))
    # print("opt_theta: %s" %(thetas[opt_index]))

    return thetas[opt_index]

def gradient_ascent_probs(X, X_returns, theta_init, predClasses, mu = 1, delta = 0.02, riskAdj=False, maxSteps=100,\
                    thresh=0.0, batchSize=0.0, alpha=0.001, precision=0.00001, verbose=False):
    # variables
    theta = theta_init
    counter = 0
    old_cost = 0
    thetas = []
    costs = []

    # get current costs
    current_cost = putils.costFunction(X, X_returns, theta, predClasses, mu, delta, riskAdj=riskAdj)  ## replace cost function here

    # update arrays
    thetas.append(theta)
    costs.append(current_cost)
    counter += 1

    while abs(current_cost - old_cost) > precision:
        # calc new theta
        old_cost = current_cost
        ## gradient calc
        gradient = putils.gradientUt(X, X_returns, theta, predClasses, mu, delta, riskAdj=riskAdj)
        ## update theta
        theta = theta + alpha * gradient
        thetas.append(theta)

        ## get cost
        current_cost = putils.costFunction(X, X_returns, theta, predClasses, mu, delta, riskAdj=riskAdj)
        costs.append(current_cost)
        counter += 1

        # prints
        if verbose:
            if counter % 10 == 0:
                print("Iteration: %s cost: %s" %(counter, current_cost))

        # break
        if counter >= maxSteps:
            break

    # optimal theta
    opt_index = np.argmax(costs)
    # print("index: %s opt_cost: %s" %(opt_index, costs[opt_index]))
    # print("opt_theta: %s" %(thetas[opt_index]))

    return thetas[opt_index]

def stochastic_gradient_ascent(X, theta_init, mu = 1, delta = 0.02, riskAdj=False, maxSteps=100,\
                               thresh=0.10, batchSize=32, alpha=0.001, precision=0.00001, verbose=False):

    assert len(X) > batchSize, print("batchSize must be < len(X)")

    # variables
    theta = theta_init.copy()
    counter = 0
    thetas = []
    totalCosts = []

    # calculate y - optimal trading scenario
    y = np.where(X > thresh, 1, np.where(X < -thresh, -1, 0))

    # batch Xʻs into arrays
    def next_batch(X, y, batchSize):
        batchSize = int(batchSize)
        for i in range(0, X.shape[0], batchSize):
            # print(i)
            yield (X[i:i+batchSize], y[i:i+batchSize])

    while True:

        # initiliaze the total loss for the epoch
        costs = []

        # loop over batched data
        for (batchX, batchY) in next_batch(X, y, batchSize):
            # cost
            current_cost = utils.costFunction(X, theta, mu, delta, riskAdj=riskAdj)
            # print(current_cost)
            costs.append(current_cost)

            # update gradient
            gradient = utils.gradientUt(batchX, theta, mu, delta, riskAdj=riskAdj)
            # print(gradient)

            # update theta
            theta += alpha*gradient
            # print(theta)

        # update losses across all batches
        batch_cost = np.average(costs)
        totalCosts.append(batch_cost)
        thetas.append(theta)

        if verbose:
            print("%s cost: %s" %(counter, batch_cost))
            print("theta: %s" %(theta))

        # break if theta is all nan
        if np.isnan(theta).all():
            break

        counter += 1

        # break if maxsteps reached
        if counter >= maxSteps:
            break

    # find optimal
    opt_index = np.argmax(totalCosts)
    # print("index: %s opt_cost: %s" %(opt_index, totalCosts[opt_index]))
    # print("opt_theta: %s" %(thetas[opt_index]))

    return thetas[opt_index]

def stochastic_gradient_ascent_probs(X, X_returns, theta_init, predClasses, mu = 1, delta = 0.02, riskAdj=False, maxSteps=100,\
                               thresh=0.10, batchSize=32, alpha=0.001, precision=0.00001, verbose=False):

    assert len(X) > batchSize, print("batchSize must be < len(X)")

    # variables
    theta = theta_init.copy()
    counter = 0
    thetas = []
    totalCosts = []

    # calculate y - optimal trading scenario
    y = np.where(X > thresh, 1, np.where(X < -thresh, -1, 0))

    # batch Xʻs into arrays
    def next_batch(X, y, batchSize):
        batchSize = int(batchSize)
        for i in range(0, X.shape[0], batchSize):
            # print(i)
            yield (X[i:i+batchSize], y[i:i+batchSize])

    while True:

        # initiliaze the total loss for the epoch
        costs = []

        # loop over batched data
        for (batchX, batchY) in next_batch(X, y, batchSize):
            # cost
            current_cost = putils.costFunction(X, X_returns, theta, predClasses, mu, delta, riskAdj=riskAdj)
            # print(current_cost)
            costs.append(current_cost)

            # update gradient
            gradient = putils.gradientUt(X, X_returns, theta, predClasses, mu, delta, riskAdj=riskAdj)
            # print(gradient)

            # update theta
            theta += alpha*gradient
            # print(theta)

        # update losses across all batches
        batch_cost = np.average(costs)
        totalCosts.append(batch_cost)
        thetas.append(theta)

        if verbose:
            print("%s cost: %s" %(counter, batch_cost))
            print("theta: %s" %(theta))

        # break if theta is all nan
        if np.isnan(theta).all():
            break

        counter += 1

        # break if maxsteps reached
        if counter >= maxSteps:
            break

    # find optimal
    opt_index = np.argmax(totalCosts)
    # print("index: %s opt_cost: %s" %(opt_index, totalCosts[opt_index]))
    # print("opt_theta: %s" %(thetas[opt_index]))

    return thetas[opt_index]