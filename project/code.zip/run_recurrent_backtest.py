"""
script to run backtest
"""

#!/usr/bin/env python3

import argparse
import os
import json
from reinforcement import Reinforcement
from datetime import datetime

# default values for optDict
optDict = {
  "thresh": 10.0,
  "batchSize": 32,
  "alpha": 0.001,
  "precision": 0.00001,
  "verbose": True
}

def getDefaultFileName():

    return "%s_%s%s%s" %(str(datetime.now().date()), datetime.now().hour, datetime.now().minute, datetime.now().second)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--numTrainDays", type=int, default=30, help="number of training days")
    ap.add_argument("--numTestDays", type=int, default=10, help="number of test days")
    ap.add_argument("--startDate", type=int, default=None, help="start date of training period")
    ap.add_argument("--dataFileName", type=str, default="ohlc_60")
    ap.add_argument("--dataPath", type=str, default="/home/tesa/cs221/project/dataFrames/HKFE/HSI/")
    ap.add_argument("--M", type=int, default=10, help="look back window of returns")
    ap.add_argument("--N", type=int, default=100, help="number of iterations")
    ap.add_argument("--mu", type=int, default=1, help="number of contracts traded")
    ap.add_argument("--delta", type=float, default=1.5, help="transaction costs in bps. 1bps = 1.0")
    ap.add_argument("--riskAdj", type=bool, default=False, help="if False tQty=mu, else tQty=prob*mu")
    ap.add_argument("--rewardFunc", type=str, default="Sortino", help="Sortino or Sharpe")
    ap.add_argument("--optimizer", type=str, default="gradient_ascent", help="sga or gradient_ascent")
    ap.add_argument("--optParamFile", type=str, default="optimizer_parameters.json", help="optimizer parameters")
    ap.add_argument("--showPlots", type=bool, default=False)
    ap.add_argument("--resultsFileName", type=str, default=getDefaultFileName(), help="results file")
    ap.add_argument("--resultsFilePath", type=str, default="/home/tesa/cs221/project/results/", help="directory to save results files")
    ap.add_argument("--pointValue", type=int, default=50, help="monetary value of one price point")

args = ap.parse_args()

## get optimizer params
if args.optParamFile != None:
    optPath = "%s/%s" %(os.getcwd(), args.optParamFile)
    optDict = json.load(open(optPath))
print("optimizerParams: %s" %(optDict))

## instantiate Reinforce
reinforce = Reinforcement(M=args.M, N=args.N, mu=args.mu, delta=args.delta, riskAdj=args.riskAdj,
                          rewardFunc=args.rewardFunc, optimizer=args.optimizer)

## initialize training, test days
print("initializing...")
reinforce.initialize(startDate=args.startDate, trainDays=args.numTrainDays, testDays=args.numTestDays, \
                     priceFileName=args.dataFileName, pricePath=args.dataPath)

## run backtest
print("running backtest...")
results = reinforce.rollCycle(**optDict)

## evaluate
filePath = "%s/%s" %(args.resultsFilePath, args.resultsFileName)
reinforce.evaluateResults(results, showPlots=args.showPlots, filePath=filePath, pointValue=args.pointValue)

