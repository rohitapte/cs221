"""
pnl functions for the recurrent reinforcement learning algo
"""
#!/usr/bin/env python3

import utils
import numpy as np
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
from datetime import datetime

def getPnlDf(reinforce, pointValue=50):
    """
    pdf["tQty"] = tradeQty
    pdf["tPx"] = tradePrice
    pdf["cost"] = cost
    pdf["inv"] = inventory
    pdf["pnl"] = pdf.cost.cumsum() + pdf.inv * pdf.TradeClose
    pdf["tNum"] = tradeCount
    pdf["flips"] = flips 
    """
    df = utils.dictToDf(reinforce.test_px)
    # reset index
    df.reset_index(inplace=True)
    df["inv"] = reinforce.position
    df["signal"] = reinforce.tradeSignals
    # add tQty
    df["tQty"] = df.inv.diff()
    df.tQty.iloc[0] = 0.0
    # fees
    df["fees"] = -reinforce.tradeCosts/10000.0 * df.px
    ## add flattening line
    if df.inv.iloc[-1] != 0.0:
        newDf = pd.DataFrame(df[-1:].values, index=[df.index[-1]+1], columns=df.columns)
        newDf.inv.iloc[-1] = 0.0
        newDf.tQty.iloc[-1] = -df.inv.iloc[-1]
        newDf.signal.iloc[-1] = 0.0
        newDf.fees.iloc[-1] = -reinforce.delta/10000.0*newDf.px.iloc[-1]*abs(newDf.tQty.iloc[-1])
        df = df.append(newDf)
    # add cost
    df["cost"] = -df.px*df.tQty
    # add pnl
    df["pnl"] = (df.cost.cumsum() + df.inv*df.px)*pointValue
    # tradeCount
    tnum = 1
    tcount = [0]*len(df)
    for i in range(len(df)):
        if df.tQty.iloc[i] != 0:
            tcount[i] = tnum
            tnum += 1
    df["tNum"] = tcount
    # netPnl
    df["netPnl"] = df.pnl + df.fees*pointValue

    return df

def getDailyPnl(pnlDf, reinforce, pointValue=50):

    # get testDates
    testDates = pnlDf.date.unique()
    testDates.sort()

    pnlDict = {}
    pnlList = []
    # get daily pnl
    for date in testDates:
        # print(date)
        df = pnlDf[pnlDf.date == date]
        # if carrying inventory in, add cost to first line
        if df.inv.iloc[0] != 0.0:
            df.cost.iloc[0] = -df.inv.iloc[0]*df.px.iloc[0]
        # if carrying inventory end of day, mark to market a bit
        # print(df.iloc[-1])
        if df.inv.iloc[-1] != 0.0:
            newDf = pd.DataFrame(df[-1:].values, index=[df.index[-1] + 1], columns=df.columns)
            newDf.inv.iloc[-1] = 0.0
            newDf.tQty.iloc[-1] = -df.inv.iloc[-1]
            newDf.signal.iloc[-1] = 0.0
            newDf.fees.iloc[-1] = -reinforce.delta / 10000.0 * newDf.px.iloc[-1] * abs(newDf.tQty.iloc[-1])
            newDf.cost.iloc[-1] = -newDf.px.iloc[-1] * newDf.tQty.iloc[-1]
            df = df.append(newDf)
        # print(df.iloc[-1])
        # add pnl
        df["pnl"] = np.where(df.inv.iloc[0] == 0, (df.cost.cumsum() + df.inv*df.px - df.cost.iloc[0])*pointValue, \
                             (df.cost.cumsum() + df.inv*df.px)*pointValue)
        # tradeCount
        tnum = 1
        tcount = [0] * len(df)
        for i in range(len(df)):
            if df.tQty.iloc[i] != 0:
                tcount[i] = tnum
                tnum += 1
        df["tNum"] = tcount
        # netPnl
        df["netPnl"] = df.pnl + df.fees * pointValue
        pnlDict[date] = df
        pnlList.append(getDailySummary(df))

    pnlSummary = pd.concat(pnlList)

    return pnlSummary, pnlDict

def getDailySummary(dayDf):

    df = pd.DataFrame({"date":[dayDf.date.iloc[0]], "pnl":[int(dayDf.pnl.iloc[-1])]})
    df.set_index("date", inplace=True)
    df["min"] = int(dayDf.pnl.min())
    df["max"] = int(dayDf.pnl.max())
    df["vol"] = int(dayDf.pnl.std())
    df["median"] = int(dayDf.pnl.median())
    df["mean"] = int(dayDf.pnl.mean())
    df["numTrades"] = int(dayDf.tNum.max())
    df["numCts"] = int(abs(dayDf.tQty).sum())
    df["fees"] = int(dayDf.fees.sum())
    df["netPnl"] = int(dayDf.netPnl.iloc[-1])

    return df

## REQUIRES DAILY PNL
def plotPnlHistogram(pnl, bins=20, title=None, savePlot=None, closePlot=False):
    """
    :param pnl: pnl array
    :param bins: number of bins for histogram
    :param title: plot title
    :param savePlot: path to save plot
    :param closePlot: True or False
    """
    fig = plt.figure()
    pnl.hist(bins=bins)
    plt.title("Daily Intraday Pnl Histogram")

    if title != None:
        fig.suptitle(title)
    else:
        fig.suptitle("%s - %s" % (pnl.index[0], pnl.index[-1]))

    if savePlot != None:
        fig.savefig(savePlot)

    plt.show()

    if closePlot:
        plt.close(fig)

    return fig

def plotCumPnlAndDailyBarChart(pnl, title=None, savePlot=None, closePlot=False):

    # get plt times
    xs, hfmt = formatStringTime(pnl.index.format(), formatType="%Y%m%d")

    ## cum pnl
    fig = plt.figure()
    ax1 = plt.subplot(211)
    ax1.plot(xs, pnl.cumsum(), "-", color="blue", label="cumPnl: %s" %(int(pnl.cumsum().iloc[-1])))
    plt.gcf().autofmt_xdate(rotation=45)
    plt.setp(ax1.get_xticklabels(), visible=False)
    ax1.set_ylabel("pnl")
    # ## annotate min pnl
    annotate_min(xs, pnl.values)
    ax1.set_title("Intraday Cumulative Pnl")
    plt.legend(loc="upper left")

    ## bar chart
    # get positive
    positive = pnl > 0
    ax2 = plt.subplot(212, sharex=ax1)
    ax2.bar(xs, pnl.values, color=positive.map({True:"green", False:"red"}))
    ax2.plot(xs, [pnl.mean()]*len(xs), "--", color="blue", label="avgPnl: %s" %(int(pnl.mean())))
    ax2.xaxis.set_major_formatter(hfmt)
    plt.gcf().autofmt_xdate(rotation=45)
    plt.setp(ax2.get_xticklabels(), fontsize=6)
    ax2.set_ylabel("pnl")
    ax2.set_title("Daily Pnl")
    plt.legend(loc="lower left")

    if title != None:
        fig.suptitle(title)
    else:
        fig.suptitle("%s - %s" %(pnl.index[0], pnl.index[-1]))

    if savePlot != None:
        fig.savefig(savePlot)

    plt.show()

    if closePlot:
        plt.close(fig)

    return fig

def plotCumPnl(pnl, title=None, savePlot=None, closePlot=False):

    # get plt times
    xs, hfmt = formatStringTime(pnl.index.format(), formatType="%Y%m%d")

    fig = plt.figure()
    ax = fig.add_subplot(1,1,1)
    ax.plot(xs, pnl.cumsum(), "-", color="blue", label="cumPnl: %s" %(int(pnl.sum())))
    ax.xaxis.set_major_formatter(hfmt)
    plt.gcf().autofmt_xdate(rotation=45)
    ax.set_ylabel("pnl")

    ## annotate min pnl
    annotate_min(xs, pnl.values)

    plt.legend(loc="upper left")

    plt.title("Daily Cumulative Pnl")
    if title != None:
        fig.suptitle(title)
    else:
        fig.suptitle("%s - %s" %(pnl.index[0], pnl.index[-1]))

    if savePlot != None:
        fig.savefig(savePlot)

    plt.show()

    if closePlot:
        plt.close(fig)

    return fig


def annotate_max(x, y, ax=None):

    xmax = x[np.argmax(y)]
    ymax = y.max()
    text = "x=%s, y=%s" %(xmax, ymax)
    if not ax:
        ax=plt.gca()
    kw = dict(xycoords='data',textcoords="axes fraction",
              ha="right", va="bottom")
    ax.annotate(text, xy=(xmax, ymax), xytext=(0.95, 0.05), **kw)

def annotate_min(x, y, ax=None):

    xmin = x[np.argmin(y)]
    ymin = y.min()
    text = "x=%s, y=%s" %(xmin, ymin)
    if not ax:
        ax=plt.gca()
    kw = dict(xycoords='data',textcoords="axes fraction",
              ha="right", va="bottom")
    ax.annotate(text, xy=(xmin, ymin), xytext=(0.95, 0.05), **kw)

def formatStringTime(timeIndex, formatType="%Y%m%d"):

    time = [datetime.strptime(x, formatType) for x in timeIndex]
    x_axis = (time)
    hfmt = matplotlib.dates.DateFormatter(formatType)

    return x_axis, hfmt