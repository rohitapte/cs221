"""
helper functions for the recurrent reinforcement learning algo

"""
import numpy as np
from scipy.optimize import fmin_bfgs


def getLogReturns(z, dt=1):
    """
    z = price array
    """
    return np.log(z / z.shift(dt)) * 1000


def sortinoRatio(ret):
    """
    ret: np.array of returns
    """
    return np.mean(ret)/np.std(ret[ret<0]) * np.sqrt(252)

def sharpeRatio(ret):
    """
    ret: np.array of returns
    """
    return np.nanmean(ret)/ np.nanstd(ret) * np.sqrt(252)


def getCumulativeReturn(tradeRet):

    cumTRet = []
    for i in range(2, len(tradeRet)):
        cumRet = (tradeRet[i-1]+1)*(tradeRet[i]+1)
        cumTRet.append(cumRet)
    return cumTRet

def getTradeRet(X, mu, delta, Ft, M, T):

    tradeRet = mu * (Ft[1:T] * X[M+1:M+T] - delta * abs(Ft[2:] - Ft[1:T]))

    return tradeRet

def rewardFunction(X, mu, delta, Ft, M, T, rewardFunc="Sortino"):
    """
    X: log returns of price @ t - @ t-1
    mu: trading position zie
    delta: transaction costs
    Ft: 
    Ft_1: previous Ft
    rewardFunc: Sortino or Sharpe 
    """

    tradeRet = getTradeRet(X, mu, delta, Ft, M, T)

    if rewardFunc == "Sortino":
        ratio = sortinoRatio(tradeRet)
    else:
        # use sharpe ratio
        ratio = sharpeRatio(tradeRet)

    return tradeRet, ratio


def updateFt(X, theta, T):

    M = len(theta) - 1
    Ft = np.zeros(T+1)

    for i in range(2,T+1):
        # xt = [1,rt, ..., rt-M, F_t-1]
        print(i)
        xt = [1]
        xt += list(X[i-1:i+M-2])
        xt += [Ft[i-1]]
        print(len(xt), theta.shape)
        xt_theta = np.dot(np.array(xt), theta)
        # print(xt_theta)
        Ft[i] = round(np.tanh(xt_theta),0)

    return Ft

def get_dFt(X, theta, T, Ft):

    M = len(theta)-1
    dFt = np.zeros((M+1, T+1))
    for i in range(2, T+1):
        # xt = [1,rt, ..., rt-M, F_t-1]
        xt = [1]
        xt += list(X[i-1:i+M-2])
        xt += [Ft[i-1]]
        xt_theta = np.dot(np.array(xt), theta)
        dFt[:,i] = (1 - np.tanh(xt_theta)**2) * (xt+theta[-1]*dFt[:,i-1])

    return dFt

def get_dUtdRt(tradeRet, T):
    """
    """

    A = sum(tradeRet) / T
    B = np.std(tradeRet[tradeRet < 0])
    dUdRt = A/np.sqrt(B-A**2) - A + A/np.sqrt(B-A**2) - B

    return dUdRt


def gradientUt(X, theta, mu, delta, M, T):
    """
    dU_T(theta) / d_theta = sum t=1_T dU_T/dRt * 
            (dRt/dFt dFt/d_theta + dRt/dFt-1 dFt-1/d_theta)
    """
    print("gradientUt")
    # updateFt
    print(theta)
    Ft = updateFt(X, theta, T)

    # get tradeRet
    tradeRet = getTradeRet(X, mu, delta, Ft, M, T)

    # calc gradient
    dFt = get_dFt(X, theta, T, Ft)
    dRt_dFt = -1*mu*delta*np.sign(Ft[2:] - Ft[1:T])
    dRt_dFt1 = mu*(X[M+1:M+T] + delta*np.sign(Ft[2:] - Ft[1:T]))
    dUt_dRt = get_dUtdRt(tradeRet, T)

    grad = sum(dUt_dRt * (dRt_dFt * dFt[:, 2:]+ dRt_dFt1 * dFt[:, 1:T]))

    return -grad

def costFunction(mu, delta, X, theta, M, T):
    """
    for fmin_bfgs, need to return score only
    """

    print("cost function")
    print(theta)

    # updateFt
    Ft = updateFt(X, theta, T)

    # get return, score using rewardFunction
    tradeRet, score = rewardFunction(X, mu, delta, Ft, M, T, rewardFunc="Sortino")

    return -score

def gradFunction(mu, delta, X, theta, M, T):
    """
    for fmin_bfgs, need to return grad only
    """

    # updateFt
    Ft = updateFt(X, theta, T)
    # get tradeRet
    tradeRet = getTradeRet(X, mu, delta, Ft, M, T)
    # get gradient
    grad = gradientUt(tradeRet, X, theta, Ft, mu, delta, M, T)

    return grad

def optimizeTheta(mu, delta, X, M, T):

    theta = np.ones(M+2)
    print("theta: %s" %(theta))

    theta_1 = fmin_bfgs(costFunction, x0=theta, fprime=gradientUt, args=(mu, delta, X, M, T))

    return theta_1