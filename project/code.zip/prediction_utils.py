"""
helper functions for the recurrent reinforcement learning algo

"""
#!/usr/bin/env python3

import numpy as np
import pandas as pd


def getY(x, thresh):

    return np.where(x > thresh, 1, np.where(x < -thresh, -1, 0))

def sortinoRatio(ret):
    """
    sortinoRatio = avg(ret) / std(ret[ret<0])
    ret: np.array of annualized returns
    """

    if np.nanstd(ret[ret<0]) != 0 and abs(ret).sum() != 0 and len(ret[ret<0]) > 0:
        return (np.nanmean(ret)/ abs(np.nanstd(ret[ret<0]))) * np.sqrt(252)
    else:
        return np.nanmean(ret) / abs(np.nanstd(ret)) * np.sqrt(252)

def sharpeRatio(ret):
    """
    sharpeRatio = avg(ret) / std(ret)
    ret: np.array of returns
    """

    if np.nanstd(ret) != 0 and abs(ret).sum() != 0 and len(ret) > 0:
        return (np.nanmean(ret)/ abs(np.nanstd(ret))) * np.sqrt(252)
    else:
        return np.nanmean(ret) * np.sqrt(252)

def getCumulativeReturn(tradeRet):
    """
    cret_t = cret_t-1 * (1+tradeRet_t)
    DONT USE WITH NEGATIVE RETURNS
    """
    cret = [1.0]
    for x in tradeRet:
        if x != 0:
            cret.append((x+1.0)*cret[-1])
            # print(x, cret[-1])
    return cret[-1]

def getPosition(mu, Ft):
    # mu*F_t
    # len(Ft)-1
    # return np.array([np.round(x, 0) for x in mu*Ft[:-1]])
    # len(Ft)
    return np.array([np.round(x, 0) for x in mu*Ft])

def getTradeCosts(mu, Ft, delta):
    # delta * mu * abs(F_t - F_t-1)
    # len(Ft) - 1
    # return delta*np.array([np.round(x, 0) for x in mu * abs(Ft[1:] - Ft[:-1])])
    # len(Ft)
    tcost = np.array([0.0])
    tcost = np.append(tcost, delta*np.array([np.round(x, 0) for x in mu*abs(Ft[1:] - Ft[:-1])]))
    return tcost

def getTradeRet(X_returns, mu, delta, Ft):
    """
    Rt = mu(F_t-1 * r_t - delta * abs(F_t - F_t-1)
    tradeRet = (len(X)-1, )
    """

    position = getPosition(mu, Ft)
    tradeCosts = getTradeCosts(mu, Ft, delta)
    ## len(Ft) - 1
    # tradeRet = position*X[1:] - tradeCosts
    ## len(Ft)
    tradeRet = position * X_returns - tradeCosts

    return tradeRet

def rewardFunction(X_returns, mu, delta, Ft, rewardFunc="Sortino"):
    """
    X: log returns of price @ t - @ t-1
    mu: trading positions
    delta: transaction costs in bps
    Ft: 
    Ft_1: previous Ft
    rewardFunc: Sortino or Sharpe 
    """

    tradeRet = getTradeRet(X_returns, mu, delta, Ft)

    if rewardFunc == "Sortino":
        ratio = sortinoRatio(tradeRet)
    else:
        # use sharpe ratio
        ratio = sharpeRatio(tradeRet)

    return tradeRet, ratio


def updateFt(X, theta, predClasses, riskAdj = False):
    """
    X: training period returns shape(T)
    theta: weight array shape(M)
    Ft: array of decisions shape(T)
    """

    Ft = np.zeros(len(X))

    for i in range(len(Ft)):
        # print(i)
        ## if predClass, xt = [1, argmax(probs), F_t-1]
        ## if target, xt = [1, target, F_t-1]
        xt = [1]
        ## if target or only 1 prediction
        if len(predClasses) > 1:
            max_index = np.argmax(X[i])
            probSign = float(predClasses[max_index])
            xt += [X[i][max_index]*probSign]
        else:
            xt += [X[i]]
            probSign = np.sign(X[i])

        # print(len(xt))
        xt += [Ft[i-1]]
        # print(np.array(xt).shape, theta.shape)
        ## xt_theta
        xt_theta = np.dot(np.array(xt), theta)
        # print(xt_theta)
        if riskAdj == False:
            Ft[i] = np.round(np.tanh(xt_theta), 0)*probSign
        else:
            Ft[i] = np.round(np.tanh(xt_theta), 2)*probSign

    return Ft

def get_dFt(X, theta, predClasses, Ft):

    M = len(theta) - 2
    dFt = np.zeros((M+2, len(X)))

    for i in range(len(Ft)):
        # print(i)
        xt = [1]
        ## if target or only 1 prediction
        if len(predClasses) > 1:
            max_index = np.argmax(X[i])
            probSign = float(predClasses[max_index])
            xt += [X[i][max_index]*probSign]
        else:
            xt += [X[i]]
        xt += [Ft[i-1]]
        # print(np.array(xt).shape, theta.shape)
        xt_theta = np.dot(np.array(xt), theta)
        # print(np.array(xt).shape, dFt[:, i-1].shape)
        dFt[:,i] = (1 - np.tanh(xt_theta)**2) * (xt+theta[-1]*dFt[:,i-1])

    return dFt

def get_dUtdRt(tradeRet):
    """
    Sharpe Ratio = (Bn - AnR)/(Kn(Bn-An^2)^(3/2))
        where An = sum(R)/n
              Bn = sum(R)^2/n
              Kn = sqrt(n/n-1)
              https://pdfs.semanticscholar.org/170c/c2f8373322ab91036bbb66fc52b5c5c37e83.pdf
              Eq. 70
    """

    if abs(tradeRet).sum() == 0:
        dUdRt = np.array([0.0]*len(tradeRet))
    else:
        A = sum(tradeRet) / len(tradeRet)
        B = sum(tradeRet)**2 / len(tradeRet)
        K = np.sqrt(len(tradeRet) / (len(tradeRet)-1))
        dUdRt = (B - A*tradeRet) / (K*(B-A**2)**(1.5))
        # dUdRt = A/np.sqrt(B-A**2) - A + A/np.sqrt(B-A**2) - B

    return dUdRt[1:]


def gradientUt(X, X_returns, theta, predClasses, mu, delta, riskAdj=False):
    """
    dU_T(theta) / d_theta = sum t=1_T dU_T/dRt * 
            (dRt/dFt dFt/d_theta + dRt/dFt-1 dFt-1/d_theta)
    """

    # updateFt
    Ft = updateFt(X, theta, predClasses, riskAdj=riskAdj)
    # print("Ft: %s" %Ft)

    # get tradeRet
    tradeRet = getTradeRet(X_returns, mu, delta, Ft)
    # print("tradeRet: %s" %tradeRet)

    # calc gradient
    dFt = get_dFt(X, theta, predClasses, Ft)
    # print("dFt: %s" %dFt)
    # dRt_dFt = -mu * delta * sign(F_t - F_t-1)
    dRt_dFt = -1*mu*delta*np.sign(Ft[1:] - Ft[:-1])
    # print("dRt_dFt: %s" %(dRt_dFt))
    # dRt_dFt1 = mu * (r_t + delta * sign(F_t - F_t-1))
    dRt_dFt1 = mu*(X_returns[1:] + delta*np.sign(Ft[1:] - Ft[:-1]))
    # print("dRt_dFt1: %s" %(dRt_dFt1))
    dUt_dRt = get_dUtdRt(tradeRet)
    # print("dUt_dRt: %s" %(dUt_dRt))
    # gradient same shape as theta
    grad = np.mean((dUt_dRt * (dRt_dFt * dFt[:, 1:]+ dRt_dFt1 * dFt[:, :-1])), axis=1)

    # print(grad)
    return -grad

def costFunction(X, X_returns, theta, predClasses, mu, delta, riskAdj=False):
    """
    for fmin_bfgs, need to return score only
    """
    # updateFt
    Ft = updateFt(X, theta, predClasses, riskAdj=riskAdj)

    # get return, score using rewardFunction
    tradeRet, score = rewardFunction(X_returns, mu, delta, Ft, rewardFunc="Sortino")

    return score

#####   EVALUATION FUNCTIONS

def dictToArray(x_dict, dictKey=None):

    x = np.array([])
    for key, item in x_dict.items():
        if dictKey==None:
            x = np.append(x, item)
        else:
            x = np.append(x, item[dictKey])

    return x

def dictToDf(x_dict):

    dfList = []
    for key, item in x_dict.items():
        dfList.append(item)

    df = pd.concat(dfList)

    return df


