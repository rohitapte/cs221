import tensorflow as tf
import LSTMData

INPUT_LENGTH=30
NUM_HIDDEN_CELLS=64
NUM_EPOCHS=20
BATCH_SIZE=5000
KEEP_PROB=0.8
NUM_LAYERS=1

market_data=LSTMData.FinancialDataObject(input_length=INPUT_LENGTH)

data=tf.placeholder(tf.float32,[None,INPUT_LENGTH,1])
target=tf.placeholder(tf.float32,[None,3])
classes_weights = tf.constant([market_data.weights[0],market_data.weights[1],market_data.weights[2]])

def _create_one_cell():
    lstm_cell = tf.contrib.rnn.LSTMCell(NUM_HIDDEN_CELLS, state_is_tuple=True)
    if KEEP_PROB < 1.0:
        lstm_cell = tf.contrib.rnn.DropoutWrapper(lstm_cell, output_keep_prob=KEEP_PROB)
    return lstm_cell

cell = tf.contrib.rnn.MultiRNNCell(
    [_create_one_cell() for _ in range(NUM_LAYERS)],
    state_is_tuple=True
) if NUM_LAYERS > 1 else _create_one_cell()


val, state = tf.nn.dynamic_rnn(cell, data, dtype=tf.float32)
val = tf.transpose(val, [1, 0, 2])
last = tf.gather(val, int(val.get_shape()[0]) - 1)

weight = tf.Variable(tf.truncated_normal([NUM_HIDDEN_CELLS, int(target.get_shape()[1])]))
bias = tf.Variable(tf.constant(0.1, shape=[target.get_shape()[1]]))

final_output=tf.matmul(last, weight) + bias

prediction = tf.nn.softmax(final_output)
#cross_entropy = -tf.reduce_sum(target * tf.log(tf.clip_by_value(prediction,1e-10,1.0)))
#softmax_cross_entropy=tf.nn.softmax_cross_entropy_with_logits(logits=final_output,labels=target)
softmax_cross_entropy=tf.nn.weighted_cross_entropy_with_logits(logits=final_output,targets=target,pos_weight=classes_weights)
cross_entropy=tf.reduce_sum(softmax_cross_entropy,name='cross_entropy')

optimizer = tf.train.AdamOptimizer()
minimize = optimizer.minimize(cross_entropy)

mistakes = tf.not_equal(tf.argmax(target, 1), tf.argmax(prediction, 1))

error = tf.reduce_mean(tf.cast(mistakes, tf.float32))

init = tf.global_variables_initializer()
sess = tf.Session()
sess.run(init)

for i in range(NUM_EPOCHS):
	print("Epoch %s"%(i))
	for x,y in market_data.generate_one_epoch(BATCH_SIZE):
		sess.run(minimize,{data: x, target: y})
	test_accuracy=sess.run(error,{data:market_data.X_test,target:market_data.y_test})
	print("Test accuracy %s"%(test_accuracy))


f=open('predictions_ohlc_60_LSTM.csv','w')
for j in range(0,market_data.X_test.shape[0]):
    test_pred=sess.run(prediction,{data:market_data.X_test[j:(j+1)],target:market_data.y_test[j:(j+1)]})
    temp=market_data.y_test[j:(j+1)]
    temp=temp[0]
    sTemp=''
    if temp[2]==1:
        sTemp='+1'
    elif temp[1]==1:
        sTemp='0'
    elif temp[0]==1:
        sTemp='-1'
    sTemp+=","
    for aa in test_pred:
        for item in aa:
            sTemp+=str(item)+','
    sTemp=sTemp[:-1]
    sTemp+='\n'
    f.write(sTemp)
#	current_pred=test_pred.tolist()
f.close()

f=open('predictions_ohlc_60_LSTM_train.csv','w')
for j in range(0,market_data.X_train.shape[0]):
    test_pred=sess.run(prediction,{data:market_data.X_train[j:(j+1)],target:market_data.y_train[j:(j+1)]})
    temp=market_data.y_train[j:(j+1)]
    temp=temp[0]
    sTemp=''
    if temp[2]==1:
        sTemp='+1'
    elif temp[1]==1:
        sTemp='0'
    elif temp[0]==1:
        sTemp='-1'
    sTemp+=","
    for aa in test_pred:
        for item in aa:
            sTemp+=str(item)+','
    sTemp=sTemp[:-1]
    sTemp+='\n'
    f.write(sTemp)
#	current_pred=test_pred.tolist()
f.close()
sess.close()
