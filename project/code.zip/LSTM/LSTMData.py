import numpy as np
import pandas as pd
import random
import time
import datetime
from sklearn.model_selection import train_test_split

random.seed(time.time())
dataPath='/home/rohitapte/Documents/ohlc_60/'

class FinancialDataObject(object):
	def __init__(self, test_ratio=0.1,input_length=10,target_column='target,tX60,tY120,10,pts'):
		df_input=pd.read_csv(dataPath + 'all_inds_ohlc_60.csv')
		cols = df_input.columns.tolist()
		cols.remove('timestamp')
		cols.remove('Date')
		cols.remove('Mid')
		cols.remove('TradeClose')
		cols.remove('TradePrice')
		df_input.drop(cols, inplace=True, axis=1)
		df_input['DateTimeCombined']=df_input.apply(lambda x: str(int(x['Date'])) + "_" + x['timestamp'][:-4], axis=1)
		df_input['DateFormatted'] = df_input['DateTimeCombined'].apply(lambda x: datetime.datetime.strptime(x, '%Y%m%d_%H:%M:%S'))

		df_target=pd.read_csv(dataPath + 'targets_ohlc_60.csv')
		df_target['DateTimeCombined']=df_target.apply(lambda x: str(int(x['Date'])) + "_" + x['timestamp'][:-4], axis=1)
		df_target['DateFormatted']=df_target['DateTimeCombined'].apply(lambda x: datetime.datetime.strptime(x, '%Y%m%d_%H:%M:%S'))
		df_target=df_target.sort_values('DateFormatted')

		df=df_input.merge(df_target,how='left',left_on=['DateFormatted'],right_on=['DateFormatted'])
		# HSI data has some rows with zero price. We will exclude this since it throws off our calculations
		df=df[df['TradeClose_x'] > 0]

		df=df.sort_values('DateFormatted')

		closing_prices=df['TradeClose_x'].tolist()
		labels=df[target_column].tolist()
		temp = df.pivot_table(values='TradeClose_x', index='target,tX60,tY120,10,pts', aggfunc='count')
		temp = temp['TradeClose_x'].tolist()
		weights = []
		for item in temp:
			weights.append(2*(1 / ((item + 0.0) / sum(temp))))


		model_input=[]
		model_output=[]
		i=input_length
		while i<=len(closing_prices):
			#model_input.append(closing_prices[i-input_length:i])
			model_input.append([[closing_prices[j]] for j in range(i-input_length,i)])
			one_hot=[0,1,0]
			if labels[i-1]==-1:
				one_hot=[1,0,0]
			elif labels[i-1]==1:
				one_hot=[0,0,1]
			model_output.append(one_hot)
			i+=1
		X=np.array(model_input)
		y=np.array(model_output)
		X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=test_ratio)

		self.X_train=X_train
		self.y_train=y_train
		self.X_test=X_test
		self.y_test=y_test
		self.df=df
		self.weights=weights

	def generate_one_epoch(self, batch_size=100):
		num_batches=int(len(self.X_train))//batch_size
		if batch_size*num_batches<len(self.X_train):
			num_batches+=1

		batch_indices=[i for i in range(num_batches)]
		random.shuffle(batch_indices)
		for j in batch_indices:
			batch_X = self.X_train[j * batch_size: (j + 1) * batch_size]
			batch_y = self.y_train[j * batch_size: (j + 1) * batch_size]
			#assert set(map(len, batch_X)) == {self.num_steps}
			yield batch_X, batch_y
