
"""

Description of TradeState and helper functions:

    A TradeState specifies the full trade state, including the position, predictions,
    pnl, and score changes. In this function, the |TradeState| argument
    is an object of TradeState class. Following are a few of the helper methods that you
    can use to query a TradeState object to gather information about the present state
    of the position, the predictions and the pnl.

    tradeState.getLegalActions():
        Returns the legal actions.

    tradeState.generateSuccessor(state, action):
        Returns the successor state following the given action.

    tradeState.getState():
        Returns State object (define in utils_og.py)
        state.pos gives the current position
        state.pnl gives the current pnl
        state.pred gives the current prediction

    tradeState.getScore():
        Returns the score corresponding to the current state of the game
        
    tradeState.getPnl():
        Returns the pnl corresponding to the current state of the game
"""