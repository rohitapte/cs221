"""
code to get assemble dataframe of dates and returns
generate a csv with returns for future use
"""
#!/usr/bin/env python3

import os
import pandas as pd
import numpy as np

dataPath = "/home/tesa/cs221/project/dataFrames/HKFE/HSI/"

def getFiles(fileName = "ohlc_60", dataPath=dataPath):
    """
    get all fileNames and sort by date
    """

    files = [f for f in os.listdir(dataPath) if fileName == f[:len(fileName)]]
    files.sort()

    return files

def getMergedDataFrames(fileName= "ohlc_60", dataPath=dataPath):

    files = getFiles(fileName=fileName, dataPath=dataPath)

    dfList = []
    for file in files:
        # print(file)
        df = pd.read_csv(dataPath + file)

        dfList.append(df)

    tdf = pd.concat(dfList)
    tdf.rename(columns={"Unnamed: 0": "timestamp"}, inplace=True)
    tdf.set_index("timestamp", inplace=True)

    return tdf

def getDf(tdf, dateList):

    return tdf[tdf.Date.isin(dateList)]


def getLogReturns(df):

    ## remove 0ʻs
    tpx = df[df.TradeClose > 0]
    ## return 1.00 bps = 0.01%
    ret = pd.DataFrame(np.log(tpx.TradeClose/tpx.TradeClose.shift(1))*10000)
    ret.columns = ["lnRet"]
    ret["px"] = tpx.TradeClose.values
    ret["date"] = tpx.Date.values
    ret.fillna(0, inplace = True)

    return ret

def getTrainTestX(startDate=None, trainDays=20, testDays=10, priceFileName="ohlc_60", pricePath=dataPath):

    tdf = getMergedDataFrames(fileName=priceFileName, dataPath=pricePath)
    if startDate != None:
        tdf = tdf[tdf.Date >= startDate]
    dateList = tdf.Date.unique()
    dateList.sort()
    # print(dateList)
    train_dates = {}
    test_dates = {}
    train_rets = {}
    test_rets = {}
    train_px = {}
    test_px = {}
    for i in range(0, int(np.ceil(len(dateList)/(testDays)))):
        trainDates = dateList[i*testDays:i*testDays+trainDays]
        testDates = dateList[i*testDays+trainDays: i*testDays+trainDays+testDays]
        # skip empty testDates
        if len(testDates) > 0:
            train_dates[i] = trainDates
            test_dates[i] = testDates
            train_df = getDf(tdf, trainDates)
            test_df = getDf(tdf, testDates)
            ## remove times
            train_df = train_df[train_df.index != "09:15:00.000"]
            train_df = train_df[train_df.index != "13:00:00.000"]
            test_df = test_df[test_df.index != "09:15:00.000"]
            test_df = test_df[test_df.index != "13:00:00.000"]
            ## get log returns
            df_train_rets = getLogReturns(train_df)
            df_test_rets= getLogReturns(test_df)
            # train
            train_px[i] = df_train_rets
            train_rets[i] = df_train_rets["lnRet"].values
            # test
            test_px[i] = df_test_rets
            test_rets[i] = df_test_rets["lnRet"].values
        else:
            break

    return train_px, test_px, train_rets, test_rets, train_dates, test_dates

def getTrainTestPreds(startDate=None, trainDays=20, testDays=10, predFileName="predictions", predPath="/home/tesa/cs221/project/predictions/",
                      priceFileName="ohlc_60", pricePath="/home/tesa/cs221/project/dataFrames/HKFE/HSI/"):

    tdf = getMergedDataFrames(fileName=predFileName, dataPath=predPath)
    pdf = getMergedDataFrames(fileName=priceFileName, dataPath=pricePath)
    if startDate != None:
        tdf = tdf[tdf.Date >= startDate]
        pdf = pdf[pdf.Date >= startDate]
    dateList = tdf.Date.unique()
    dateList.sort()
    # print(dateList)
    train_dates = {}
    test_dates = {}
    train_preds = {}
    test_preds = {}
    train_px = {}
    test_px = {}
    for i in range(0, int(np.ceil(len(dateList)/(testDays)))):
        trainDates = dateList[i*testDays:i*testDays+trainDays]
        testDates = dateList[i*testDays+trainDays: i*testDays+trainDays+testDays]
        # skip empty testDates
        if len(testDates) > 0:
            train_dates[i] = trainDates
            test_dates[i] = testDates
            # get dfs
            train_pred_df = getDf(tdf, trainDates)
            test_pred_df = getDf(tdf, testDates)
            train_price_df = getDf(pdf, trainDates)
            test_price_df = getDf(pdf, testDates)
            ## remove "09:15:00.000" and "13:00:00.000"
            train_pred_df = train_pred_df[train_pred_df.index != "09:15:00.000"]
            train_pred_df = train_pred_df[train_pred_df.index != "13:00:00.000"]
            test_pred_df = test_pred_df[test_pred_df.index != "09:15:00.000"]
            test_pred_df = test_pred_df[test_pred_df.index != "13:00:00.000"]
            train_price_df = train_price_df[train_price_df.index != "09:15:00.000"]
            train_price_df = train_price_df[train_price_df.index != "13:00:00.000"]
            test_price_df = test_price_df[test_price_df.index != "09:15:00.000"]
            test_price_df = test_price_df[test_price_df.index != "13:00:00.000"]
            # get returns
            df_train_rets = getLogReturns(train_price_df)
            df_test_rets= getLogReturns(test_price_df)
            # train
            train_px[i] = df_train_rets
            train_preds[i] = train_pred_df
            # test
            test_px[i] = df_test_rets
            test_preds[i] = test_pred_df
        else:
            break

    return train_px, test_px, train_preds, test_preds, train_dates, test_dates