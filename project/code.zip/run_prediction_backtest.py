"""
script to run backtest for target and prediction
"""

#!/usr/bin/env python3

import argparse
import os
import json
from prediction_reinforcement import PredictionReinforcement
from datetime import datetime

# default values for optDict
optDict = {
  "thresh": 10.0,
  "batchSize": 32,
  "alpha": 0.001,
  "precision": 0.00001,
  "verbose": True
}

def getDefaultFolderName():

    return "%s_%s%s%s" %(str(datetime.now().date()), datetime.now().hour, datetime.now().minute, datetime.now().second)

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--numTrainDays", type=int, default=30, help="number of training days")
    ap.add_argument("--numTestDays", type=int, default=10, help="number of test days")
    ap.add_argument("--startDate", type=int, default=None, help="start date of test days")
    ap.add_argument("--predClasses", nargs="+", default=["target"], help="names of predClasses")
    ap.add_argument("--predFileName", type=str, default="predictions_ohlc_60_ET_7")
    ap.add_argument("--predPath", type=str, default="/home/tesa/cs221/project/predictions/")
    ap.add_argument("--priceFileName", type=str, default="ohlc_60")
    ap.add_argument("--pricePath", type=str, default="/home/tesa/cs221/project/dataFrames/HKFE/HSI/")
    ap.add_argument("--M", type=int, default=10, help="look back window of returns")
    ap.add_argument("--N", type=int, default=100, help="number of iterations")
    ap.add_argument("--mu", type=int, default=1, help="number of contracts traded")
    ap.add_argument("--delta", type=float, default=1.5, help="transaction costs in bps. 1bps = 1.0")
    ap.add_argument("--riskAdj", type=bool, default=False, help="if False tQty=mu, else tQty=prob*mu")
    ap.add_argument("--rewardFunc", type=str, default="Sortino", help="Sortino or Sharpe")
    ap.add_argument("--optimizer", type=str, default="gradient_ascent", help="sga or gradient_ascent")
    ap.add_argument("--optParamFile", type=str, default="optimizer_parameters.json", help="optimizer parameters")
    ap.add_argument("--showPlots", type=bool, default=False)
    ap.add_argument("--resultsFileName", type=str, default=getDefaultFolderName(), help="results folder")
    ap.add_argument("--resultsFilePath", type=str, default="/home/tesa/cs221/project/results/", help="directory to save results files")
    ap.add_argument("--pointValue", type=int, default=50, help="monetary value of one price point")

args = ap.parse_args()


## get optimizer params
if args.optParamFile != None:
    optPath = "%s/%s" %(os.getcwd(), args.optParamFile)
    optDict = json.load(open(optPath))
print("optimizerParams: %s" %(optDict))

## instantiate Reinforce
reinforce = PredictionReinforcement(N=args.N, mu=args.mu, delta=args.delta, riskAdj=args.riskAdj,
                          rewardFunc=args.rewardFunc, optimizer=args.optimizer)

## initialize training, test days
print("initializing...")
print("predClasses: %s" %(args.predClasses))
reinforce.initialize(args.numTrainDays, args.numTestDays, startDate=args.startDate, predClasses=args.predClasses, predFileName=args.predFileName, \
                     predPath=args.predPath, priceFileName=args.priceFileName, pricePath=args.pricePath)

## run backtest
print("running backtest...")
results = reinforce.rollCycle(**optDict)

## evaluate
filePath = "%s/%s" %(args.resultsFilePath, args.resultsFileName)
reinforce.evaluateResults(results, showPlots=args.showPlots, filePath=filePath, pointValue=args.pointValue)

